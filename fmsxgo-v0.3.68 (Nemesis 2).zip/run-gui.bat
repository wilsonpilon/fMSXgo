@echo off
fmsxgo.exe
